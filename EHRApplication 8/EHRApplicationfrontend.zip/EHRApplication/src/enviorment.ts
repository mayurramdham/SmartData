export const firebaseConfig = {
  apiKey: 'AIzaSyDJ3Cy1rfsm52I4Ptvzzozo3oW1nSjB4A8',
  authDomain: 'ehr-application-16d1e.firebaseapp.com',
  projectId: 'ehr-application-16d1e',
  storageBucket: 'ehr-application-16d1e.firebasestorage.app',
  messagingSenderId: '905086021010',
  appId: '1:905086021010:web:f0a661fde874791243e54b',
  measurementId: 'G-P54RM2S08X',
};
