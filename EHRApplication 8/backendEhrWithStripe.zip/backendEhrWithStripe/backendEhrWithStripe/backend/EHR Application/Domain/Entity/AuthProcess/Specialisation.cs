﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entity.AuthProcess
{
    public class Specialisation
    {
        public int Id { get; set; }
        public string SpecialisationName { get; set; }
    }
}
