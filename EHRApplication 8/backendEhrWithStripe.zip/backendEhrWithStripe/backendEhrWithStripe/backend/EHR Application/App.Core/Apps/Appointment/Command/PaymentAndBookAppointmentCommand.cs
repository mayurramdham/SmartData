﻿using App.Core.Interface;
using Domain.Entity.Appointments;
using Domain.Model;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace App.Core.Apps.Appointment.Command
{
    public class PaymentAndBookAppointmentCommand : IRequest<object>
    {
        public PaymentAndBookAppointmentDto paymentAndBookAppointmentDto { get; set; }
    }
    internal class PaymentAndBookAppointmentCommandHandler : IRequestHandler<PaymentAndBookAppointmentCommand, object>
    {
        private readonly IAppDbContext _appDbContext;
        private readonly IStripePaymentService _stripePaymentService;
        private readonly IEmailService _emailService;

        public PaymentAndBookAppointmentCommandHandler(IAppDbContext appDbContext, IStripePaymentService stripePaymentService,
            IEmailService emailService)
        {
            _appDbContext = appDbContext;
            _stripePaymentService = stripePaymentService;
            _emailService = emailService;
        }

        public async Task<object> Handle(PaymentAndBookAppointmentCommand request, CancellationToken cancellationToken)
        {
            var bookAppointmentDto = request.paymentAndBookAppointmentDto;

            var appointmentDate = bookAppointmentDto.AppointmentDate;
            var providerId = bookAppointmentDto.ProviderId;
            var patientId = bookAppointmentDto.PatientId;
            var patient = await _appDbContext.Set<Domain.Entity.AuthProcess.User>()
                      .FirstOrDefaultAsync(u => u.Id == patientId, cancellationToken);

            if (patient is null)
                return   new { staus = 404, msg = "User not found " };

            var provider = await _appDbContext.Set<Domain.Entity.AuthProcess.User>()
                          .FirstOrDefaultAsync(u => u.Id == providerId, cancellationToken);

            if (provider is null)
                return new { staus = 404, msg = "User not found " };

            var newAppointment = new Domain.Entity.Appointments.Appointment()
            {
                AppointmentDate = appointmentDate,
                Status = "Scheduled",
                User = patient,
                PatientId = patient.Id,
                ChiefComplaint = bookAppointmentDto.ChiefComplaint,
                Fees = provider.VisitingCharge,
                AppointmentTime = bookAppointmentDto.AppointmentTime,
                ProviderId = providerId,
            };

            await _appDbContext.Set<Domain.Entity.Appointments.Appointment>()
                  .AddAsync(newAppointment);

            var paymentAndOrderDto = new Striprequestmodel()
            {
                Amount = bookAppointmentDto.Amount,
                CustomerEmail = bookAppointmentDto.CustomerEmail,
                CustomerName = bookAppointmentDto.CustomerName,
                SourceToken = bookAppointmentDto.SourceToken,
                Id = bookAppointmentDto.PatientId
            };

            
            var paymentInfo = await _stripePaymentService.CreateStripePayment(paymentAndOrderDto);
            if (paymentInfo is null)
            {
                return new { staus = 404, msg = "Your Payment Fail" };
            }

            await _appDbContext.SaveChangesAsync();

            var body = "Dear " + patient.FirstName + " " + patient.LastName + ",\n\n" +
            "Your appointment has been scheduled with Dr. " + provider.FirstName + " " + provider.LastName + ".\n\n" +
            "Appointment Details:\n" +
            "Date: " + appointmentDate.ToString("MMMM dd, yyyy") + "\n" +
            "Time: " + newAppointment.AppointmentTime.ToString("hh:mm tt") + "\n\n" +
            "We look forward to seeing you soon.\n\n" +
            "Best regards,\n" +
            "Your Healthcare Provider";



            await _emailService.SendEmailAsync(patient.Email, patient.FirstName,
               "Appointment Booking Confirmation", body);

           await _emailService.SendEmailAsync(provider.Email, provider.FirstName,
             "Appointment Booking Confirmation", body);

            return new { status = 200, message = "Your Appointment Booked Successfully" };
        }
    }
}
