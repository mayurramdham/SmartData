import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ApiIntergrateServiceService {
  constructor(private http: HttpClient) {}
  registerData(data: any): Observable<any> {
    return this.http.post<any>(
      'https://localhost:7059/api/User/register',
      data
    );
  }
  LoginApi(data: any): Observable<any> {
    return this.http.post('https://localhost:7059/loginUser', data);
  }
  getUserById(id: number): Observable<any> {
    return this.http.get(`https://localhost:7059/api/User/${id}`);
  }
  getAllUser(): Observable<any> {
    return this.http.get('https://localhost:7059/api/User');
  }
  deleteUser(id: number): Observable<any> {
    return this.http.delete(`https://localhost:7059/api/User/${id}`);
  }
  updateUser(user: any): Observable<any> {
    return this.http.put<any>(
      `https://localhost:7059/api/User/${user.Id}`,
      user
    );
  }
}
