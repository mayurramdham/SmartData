import { Component, inject, OnInit } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar.component';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ApiIntergrateServiceService } from '../../servies/api-intergrate-service.service';
import { CommonModule } from '@angular/common';
import { AuthServiceService } from '../../servies/auth-service.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [NavbarComponent, ReactiveFormsModule, CommonModule],
  templateUrl: './users.component.html',
  styleUrl: './users.component.css',
})
export class UsersComponent implements OnInit {
  private apiService = inject(ApiIntergrateServiceService);
  private authService = inject(AuthServiceService);
  private toastr = inject(ToastrService);

  ngOnInit(): void {
    this.getUsers();
  }
  updateUserToastr() {
    this.toastr.warning('user updated successfully', '', {
      closeButton: true,
    });
  }
  DeleteUserToastr() {
    this.toastr.error('user deleted successfully', '', {
      closeButton: true,
    });
  }
  data: any[] = [];
  user: any = {};
  isEditMode = false;
  userForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.userForm = this.fb.group({
      firstName: [''],
      lastName: [''],
      userEmail: [''],
      roles: [''],
      address: [''],
    });
  }

  // Open modal and populate form with user data
  // openEditModal(user: any): void {}
  openEditModal(user: any): void {
    // Set the form values with the selected user's data
    this.isEditMode = true;
    this.userForm.patchValue({
      firstName: user.FirstName,
      lastName: user.LastName,
      userEmail: user.UserEmail,
      roles: user.Roles,
      address: user.Address,
    });

    this.user = user;
  }

  // updates api
  onSubmit(): void {
    if (this.userForm.valid) {
      const updatedUser = {
        ...this.user,
        ...this.userForm.value,
      };

      this.apiService.updateUser(updatedUser).subscribe(
        (response) => {
          alert('User updated successfully');
          this.isEditMode = false; // Close the edit form
          this.updateUserToastr();
          this.getUsers(); // Refresh the user list
        },
        (error) => {
          console.error(error);
          alert('Error updating user');
        }
      );
    } else {
      alert('Please fill in all required fields');
    }
  }

  // Delete user action
  deleteUser(userId: number): void {
    if (confirm('Are you sure you want to delete this user?')) {
      this.apiService.deleteUser(userId).subscribe(
        (response) => {
          this.DeleteUserToastr()
          alert(response.message); // Success message
        },
        (error) => {
          console.error(error);
          alert('Error deleting user');
        }
      );
    }
  }

  getUsers() {
    console.log('GetPAtient Called');

    this.apiService.getAllUser().subscribe(
      (res: any) => {
        if (res.status == 200) {
          localStorage.getItem('accessToken');
          this.data = res.data;
          console.log('getAllUserData', this.data);
        } else {
          console.error('Error occured');
        }
      },
      (error) => {
        console.log('error not executed getAll');
      }
    );
  }
}
